<!DOCTYPE html>
<!--[if lt IE 7 ]> <html lang="en" class="ie6"> <![endif]-->
<!--[if IE 7 ]>    <html lang="en" class="ie7"> <![endif]-->
<!--[if IE 8 ]>    <html lang="en" class="ie8"> <![endif]-->
<!--[if IE 9 ]>    <html lang="en" class="ie9"> <![endif]-->
<!--[if (gt IE 9)|!(IE)]><!-->
<html lang="en">
<!--<![endif]-->


<meta http-equiv="content-type" content="text/html;charset=UTF-8" />


<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
	<title>Viya — Showcase</title>
	
	<meta name="keywords" content="">
	<meta name="author" content="designed by http://solankimimoh.tumblr.com/">
	<meta name="viewport" content="width=device-width, initial-scale=0.5, maximum-scale=1.0, minimum-scale=1.0" />
	<meta name="HandheldFriendly" content="True">
	<link rel="shortcut icon" href="img/fav.html">
	<link rel="icon" href="favicon.html" type="image/gif">
	<link type="text/css" href="css/global.css" rel="stylesheet">
	
	  <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/full-slider.css" rel="stylesheet">

</head>

<body id="collection">
      <header id="main" class="transition">
		<?php include('templates/header.php'); ?>
	</header>
        <div id="container"><section id="section-collection" class="clearfix on">	<header id="header-collection" class="clearfix">
		
	</header>
	<div class="clearfix on">
				<figure data-url="cubistfrieze" class="cubistfrieze">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-372-w700-h700-x553-y0-xx2052-yy1500-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-372-w700-h700-x553-y0-xx2052-yy1500-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/cubistfrieze"></a>
						<h4>Cubist Frieze</h4>
					</figcaption>
				</div>
				</figure>
				<figure data-url="scribblewallsconce" class="scribblewallsconce">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-446-w700-h700-g0-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-446-w700-h700-g0-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/scribblewallsconce"></a>
						<h4>Scribble Wall Sconce</h4>
					</figcaption>
				</div>
				</figure>
				<figure data-url="picassotriowallsconce" class="picassotriowallsconce">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-429-w700-h700-g0-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-429-w700-h700-g0-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/picassotriowallsconce"></a>
						<h4>Picasso Trio Wall Sconce</h4>
					</figcaption>
				</div>
				</figure>
				<figure data-url="goldenpyramidwallsconce" class="goldenpyramidwallsconce">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-382-w700-h700-x580-y0-xx2079-yy1500-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-382-w700-h700-x580-y0-xx2079-yy1500-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/goldenpyramidwallsconce"></a>
						<h4>Golden Pyramid Wall Sconce</h4>
					</figcaption>
				</div>
				</figure>
				<figure data-url="colosseumwallsconce" class="colosseumwallsconce">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-302-w700-h700-g0-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-302-w700-h700-g0-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/colosseumwallsconce"></a>
						<h4>Colosseum Wall Sconce</h4>
					</figcaption>
				</div>
				</figure>
				<figure data-url="goldenmingcloudswallsconce" class="goldenmingcloudswallsconce">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-326-w700-h700-x86-y0-xx1073-yy985-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-326-w700-h700-x86-y0-xx1073-yy985-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/goldenmingcloudswallsconce"></a>
						<h4>Golden Ming Clouds Wall Sconce</h4>
					</figcaption>
				</div>
				</figure>
				<figure data-url="persepoliswallsconce" class="persepoliswallsconce">
						<div class="padding"><img data-src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-301-w700-h700-g0-q80.jpg" src="http://yesassets.s3.amazonaws.com/viyahome/cache/viyahome-301-w700-h700-g0-q80.jpg" class="on"></div>
				<div class="title">
					<figcaption>
						<a href="/collections/wallsculptures/persepoliswallsconce"></a>
						<h4>Persepolis Wall Sconce</h4>
					</figcaption>
				</div>
				</figure>
	</div>
</section></div>
<script type="text/javascript" src="/build/viyahome.min.js"></script>

</body>
</html>
