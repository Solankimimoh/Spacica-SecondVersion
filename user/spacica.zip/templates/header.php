
<nav class="clearfix">
			<div id="nav-left">
				<h2><a class="collections" href="collections.php">Collections</a></h2>
		
			</div>
			<div id="nav-right">
				<h2><a class="profile" href="#">Profile</a></h2>
				<h2><a class="contact" href="#">Contact</a></h2>
			</div>
			<h1><a class="showcase" href="index.php"><span>SPACICA</span></a></h1>
		</nav>


